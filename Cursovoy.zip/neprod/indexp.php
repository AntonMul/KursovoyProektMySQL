
<?require 'tpl/header.php';?><!-- header -->
<?require 'tpl/body.php';?><!-- body -->
<?require 'tpl/content.php';?><!-- content -->
<?require 'tpl/content2.php';?><!-- content2 -->
<!-- <?require 'tpl/carousel.php';?> carousel -->
<?require 'tpl/footer.php';?><!-- footer -->

