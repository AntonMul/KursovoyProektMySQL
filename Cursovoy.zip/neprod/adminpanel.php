<?require 'tpl/header.php';?><!-- header -->
<?require 'tpl/body.php';?><!-- body -->
<?require 'tpl/admin.php';?>
<?require 'tpl/footer.php';?><!-- footer -->