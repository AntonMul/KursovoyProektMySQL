<?php

$dbhost = "localhost";
$dbname = "neprod";
$username = "root";
$password = "root";

$db = new PDO("mysql:host=$dbhost; dbname=$dbname", $username, $password);

function get_product_all() {
    global $db;
    $product = $db->query("SELECT * FROM product");
    return $product;
}
function get_price_by_id($id) {
    global $db;
    $price = $db->query("SELECT * FROM price WHERE id = $id");
    $price = $price[0];
    $price = $price["cost"];
    return $price;
}
?>

