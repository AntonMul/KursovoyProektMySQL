<?require 'tpl/header.php';?>
<?require 'tpl/bodycab.php';?>
<?php if(isset($_COOKIE['user'])): ?>
    <div>

    </div>
    <div class="container mt-5">
        <div class="card text-white bg-danger mb-3" style="max-width: 20rem;">
                <div class="card-header">Пользователь</div>
                <div class="card-body">
                  <h4 class="card-title"><?= $_COOKIE['user'] ?></h4>
                </div>
              </div>
        </div>
        <div>
        <div class="container mt-3">
            <form action="tpl/mess.php" method="post">
            <input type="text" class="form-control" name="text"
            id="login" placeholder="Собщение"><br>
            <button class="w-100 btn btn-lg btn-primary" type="submit">Отправить</button>
        </form>
            </div>
        </div>
        <?php if(isset($_COOKIE['name'])): ?>
        <div class="container mt-5">
        <div class="card text-white bg-primary mb-3" style="max-lenght: 20rem;">
                <div class="card-header">Товар</div>
                <div class="card-body">
                  <h4 class="card-title"><?= $_COOKIE['name'] ?></h4>
              </div>
              <a class="w-100 btn btn-lg btn-danger" type="submit" href="tpl/deleteproduct.php">Отменить</a>
        </div>
        <?php endif; ?>
<?php endif; ?>
<?require 'tpl/footer.php';?>