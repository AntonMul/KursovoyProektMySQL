<?
function get_category_all(){
    global $db;
}
?>