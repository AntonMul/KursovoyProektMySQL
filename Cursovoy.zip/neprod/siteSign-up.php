<?require 'tpl/header.php';?>
<?require 'tpl/body.php';?>
<?require 'tpl/sign-up.php';?>
<?require 'tpl/footer.php';?>