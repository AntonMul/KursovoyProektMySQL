<?
    $text = filter_var(trim($_POST['text']),
    FILTER_SANITIZE_STRING);
    
    $mysql = new mysqli('localhost','root','root','neprod');
    $mysql->query("INSERT INTO `mess`(`text`) VALUES('$text')");
    $mysql->close();
    header('location: \cabinet.php');
    

?>