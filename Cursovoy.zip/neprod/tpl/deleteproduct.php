<?
    setcookie('name',"", time() - 3600, "/");
    header('location: \cabinet.php');
?>