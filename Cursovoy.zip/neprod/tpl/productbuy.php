<?
$mysql = new mysqli('localhost','root','root','neprod');
    $result3 = $mysql->query("SELECT * FROM `product`");
    $buy = $result3->fetch_assoc();

    setcookie('name',$buy['name'], time() + 3600, "/");

    $mysql->close();

    header('location: \cabinet.php');

?>