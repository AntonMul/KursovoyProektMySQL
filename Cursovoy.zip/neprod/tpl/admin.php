<?

    $pr_id = filter_var(trim($_POST['id']),
    FILTER_SANITIZE_STRING);
    $stat = filter_var(trim($_POST['status']),
    FILTER_SANITIZE_STRING); 
    $nam = filter_var(trim($_POST['name']),
    FILTER_SANITIZE_STRING);
    $des = filter_var(trim($_POST['text']),
    FILTER_SANITIZE_STRING);
    $cat_id = filter_var(trim($_POST['category_id']),
    FILTER_SANITIZE_STRING); 
    $price_id = filter_var(trim($_POST['price_id']),
    FILTER_SANITIZE_STRING); 
   
    $mysql = new mysqli('localhost','root','root','neprod');
    $mysql->query("INSERT INTO `product`(`id`, `status`, `name`,`text',`category_id',`price_id`) VALUES('$pr_id','$stat','$nam',$des',$cat_id',$price_id')");
    $mysql->close();
?>
<link rel="stylesheet" href="css/style.css">
<div class="container mt-5">
    <h1>Внесение товара</h1>
        <form action="tpl/input.php" method="post">
            <input type="text" class="form-control" name="pr_id"
            id="input" placeholder="ID"><br>
            <input type="text" class="form-control" name="stat"
            id="input" placeholder="Статус"><br>
            <input type="text" class="form-control" name="nam"
            id="input" placeholder="Название продукта"><br>
            <input type="text" class="form-control" name="des"
            id="input" placeholder="Описание"><br>
            <input type="text" class="form-control" name="cat_id"
            id="input" placeholder="Категория ID"><br>
            <input type="text" class="form-control" name="price_id"
            id="input" placeholder="Прайс ID"><br>
            <button class="w-100 btn btn-lg btn-primary" type="submit">Выполнить</button>
        </form>
    </div>