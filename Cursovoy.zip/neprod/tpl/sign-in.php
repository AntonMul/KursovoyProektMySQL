<link rel="stylesheet" href="css/style.css">
<div class="container mt-5">
        <h1>Авторизация</h1>
        <form action="tpl/auth.php" method="post">
            <input type="text" class="form-control" name="login"
            id="login" placeholder="Логин"><br>
            <input type="password" class="form-control" name="pass"
            id="login" placeholder="Пароль"><br>
            <button class="w-100 btn btn-lg btn-primary" type="submit">Авторизоваться</button>
        </form>
    </div>