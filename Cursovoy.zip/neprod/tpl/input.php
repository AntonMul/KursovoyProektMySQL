<?

    $pr_id = filter_var(trim($_POST['id']),
    FILTER_SANITIZE_STRING);
    $stat = filter_var(trim($_POST['status']),
    FILTER_SANITIZE_STRING); 
    $nam = filter_var(trim($_POST['name']),
    FILTER_SANITIZE_STRING);
    $des = filter_var(trim($_POST['text']),
    FILTER_SANITIZE_STRING);
    $cat_id = filter_var(trim($_POST['category_id']),
    FILTER_SANITIZE_STRING); 
    $price_id = filter_var(trim($_POST['price_id']),
    FILTER_SANITIZE_STRING); 
   
    $mysql = new mysqli('localhost','root','root','neprod');
    $mysql->query("INSERT INTO `product`(`id`, `status`, `name`,`text',`category_id',`price_id`) VALUES('$pr_id','$stat','$nam',$des',$cat_id',$price_id')");
    $mysql->close();
?>