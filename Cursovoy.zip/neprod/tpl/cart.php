<?
$quantity = $_POST["quantity"];
$productCode = $_POST["productCode"];
$cart = isset($_COOKIE["cart"]) ? $_COOKIE["cart"] : "[]";
$cart = json_decode($cart);
$result = mysql_query($db, "SELECT * FROM product WHERE productCode = '". $productCode."'"   );
$product = mysql_fetch_object($result);
array_push($cart, array(
    "productCode"-> $productCode,
    "quntity"->$quantity,
    "product"->$product
));
setcookie("cart",json_encode($cart));
header("location: /")
?>