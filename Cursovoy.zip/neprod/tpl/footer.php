<div class="container">
  <footer class="py-3 my-4">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
      <li class="nav-item"><a href="indexp.php" class="nav-link px-2 text-muted">Главная</a></li>

    </ul>
    <p class="text-center text-muted">© 2023 SportTren</p>
  </footer>
</div>